/** @file
  * @brief Setting lights
  *
  * Modules for control of the lights.
  */

/** 
  * @brief Clears all lights setting them low.
  */
void lights_clear_all_lights();


